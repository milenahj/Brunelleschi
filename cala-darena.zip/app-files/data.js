var APP_DATA = {
  "scenes": [
    {
      "id": "0-cala-darena-1",
      "name": "cala d'arena 1",
      "levels": [
        {
          "tileSize": 256,
          "size": 256,
          "fallbackOnly": true
        },
        {
          "tileSize": 512,
          "size": 512
        },
        {
          "tileSize": 512,
          "size": 1024
        },
        {
          "tileSize": 512,
          "size": 2048
        }
      ],
      "faceSize": 2048,
      "initialViewParameters": {
        "yaw": 0.315243051503753,
        "pitch": 0,
        "fov": 1.1295095994859854
      },
      "linkHotspots": [],
      "infoHotspots": []
    }
  ],
  "name": "cala d'arena",
  "settings": {
    "mouseViewMode": "drag",
    "autorotateEnabled": false,
    "fullscreenButton": true,
    "viewControlButtons": true
  }
};
